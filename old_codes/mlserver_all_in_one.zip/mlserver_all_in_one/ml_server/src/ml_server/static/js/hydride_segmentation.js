// Hydride Segmentation UI logic aligned with GUI.py params
// - Shows elapsed time in report
// - Adds "Download ZIP" button
// - Guards against duplicate submissions

document.addEventListener('DOMContentLoaded', function () {
  // Elements
  const form = document.getElementById('segmentForm');
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('image');
  const browseBtn = document.getElementById('browse-button');
  const fileName = document.getElementById('file-name');
  const thumbWrap = document.getElementById('thumb-wrap');
  const thumb = document.getElementById('thumb');
  const metaLine = document.getElementById('meta-line');
  const sampleCol = document.getElementById('sample-col');  // NEW

  const algoSelect = document.getElementById('algorithm');
  const convFields = document.getElementById('conv-fields');

  const statusArea = document.getElementById('status-area');
  const statusAlert = document.getElementById('status-alert');

  const reportCard = document.getElementById('report-card');
  const resultsSection = document.getElementById('results-section');
  const runBtn = document.getElementById('run-btn');
  const resetBtn = document.getElementById('reset-btn');

  const imgInput = document.getElementById('img_input');
  const imgMask = document.getElementById('img_mask');
  const imgOverlay = document.getElementById('img_overlay');
  const imgOrientation = document.getElementById('img_orientation');
  const imgSizeHist = document.getElementById('img_size_hist');
  const imgAngleHist = document.getElementById('img_angle_hist');
  const metricArea = document.getElementById('metric_area');
  const metricCount = document.getElementById('metric_count');

  const reportBox = document.getElementById('result_report'); // <pre>
  const copyBtn = document.getElementById('copy-report-btn');
  const downloadZipBtn = document.getElementById('download-zip-btn');

  // Params (GUI-aligned)
  const p_clip = document.getElementById('clahe_clip_limit');
  const p_grid = document.getElementById('clahe_tile_grid');
  const p_ablock = document.getElementById('adaptive_block_size'); // odd ≥ 3
  const p_ac = document.getElementById('adaptive_c');              // int
  const p_mkerxy = document.getElementById('morph_kernel_xy');     // "X,Y"
  const p_mitr = document.getElementById('morph_iters');           // ≥ 0
  const p_area = document.getElementById('area_threshold');        // ≥ 0
  const p_crop = document.getElementById('crop_image');            // checkbox
  const p_cpercent = document.getElementById('crop_percent');      // 0..90

  const API_SEGMENT = '/api/v1/hydride_segmentation/segment';
  const API_ZIP = '/api/v1/hydride_segmentation/zip';
  const MAX_BYTES = 20 * 1024 * 1024; // 20 MB

  // Single-request guard
  let inFlight = null;   // AbortController
  let inProgress = false;

  function updateSampleVisibility() {
    if (!sampleCol) return;
    const hasFile = !!(fileInput && fileInput.files && fileInput.files.length);
    sampleCol.hidden = hasFile;           // hide when a real file is selected
  }
  // --- Helpers
  function showStatus(kind, msg) {
    statusArea.hidden = false;
    statusAlert.className = 'alert';
    statusAlert.classList.add(kind === 'error' ? 'alert-danger' : 'alert-info');
    statusAlert.textContent = msg;
  }
  function clearStatus() { statusArea.hidden = true; statusAlert.textContent = ''; statusAlert.className = 'alert'; }
  function showResults(on) { resultsSection.hidden = !on; }
  function showReport(on)  { reportCard.hidden = !on; }
  function setImg(el, b64) { el.src = b64 ? ('data:image/png;base64,' + b64) : ''; }
  function parsePair(s, label, min = 1) {
    const parts = (s || '').split(',').map(t => t.trim());
    if (parts.length !== 2) throw new Error(`${label} must be 'X,Y'`);
    const x = parseInt(parts[0], 10), y = parseInt(parts[1], 10);
    if (!Number.isInteger(x) || !Number.isInteger(y) || x < min || y < min) {
      throw new Error(`${label} X,Y must be integers \u2265 ${min}`);
    }
    return `${x},${y}`;
  }
  const isOdd = n => (n % 2) !== 0;

  // Enable/disable crop percent
  p_crop?.addEventListener('change', () => {
    p_cpercent.disabled = !p_crop.checked;
    if (!p_crop.checked) p_cpercent.value = '10';
    recomputeReadyState();
  });

  function validateParams() {
    const clip = Number(p_clip.value);
    if (!(clip > 0)) throw new Error('CLAHE clip limit must be > 0');

    const grid = parsePair(p_grid.value, 'CLAHE tile grid', 1);

    const ablock = parseInt(p_ablock.value, 10);
    if (!Number.isInteger(ablock) || ablock < 3 || !isOdd(ablock)) {
      throw new Error('Adaptive Block Size must be an odd integer \u2265 3');
    }

    const ac = parseInt(p_ac.value, 10);
    if (!Number.isInteger(ac)) throw new Error('Adaptive C must be an integer');

    const mxy = parsePair(p_mkerxy.value, 'Morph kernel size', 1);

    const mi = parseInt(p_mitr.value, 10);
    if (!Number.isInteger(mi) || mi < 0) {
      throw new Error('Morph iterations must be an integer \u2265 0');
    }

    const area = parseInt(p_area.value, 10);
    if (!Number.isInteger(area) || area < 0) {
      throw new Error('Area threshold must be an integer \u2265 0');
    }

    let crop = false, cpercent = 0;
    if (p_crop.checked) {
      crop = true;
      cpercent = parseInt(p_cpercent.value, 10);
      if (!Number.isInteger(cpercent) || cpercent < 0 || cpercent > 90) {
        throw new Error('Crop percent must be 0..90');
      }
    }

    return { clip, grid, ablock, ac, mxy, mi, area, crop, cpercent };
  }

  function validateFile(file) {
    if (!file) throw new Error('Please choose an image file');
    if (file.size > MAX_BYTES) throw new Error('File too large (> 20 MB)');
    if (!file.type || !file.type.startsWith('image/')) {
      const name = (file.name || '').toLowerCase();
      const okExt = /\.(png|jpe?g|tif?f|bmp)$/i.test(name);
      if (!okExt) throw new Error('Unsupported file type (PNG/JPG/TIFF/BMP only)');
    }
  }

  function recomputeReadyState() {
    try {
      const file = fileInput.files[0];
      validateFile(file);
      validateParams();
      runBtn.disabled = false;
    } catch { runBtn.disabled = true; }
  }

  // Build FormData from current UI state (reuse for both /segment and /zip)
  function buildFormData() {
    const file = fileInput.files[0];
    const algo = algoSelect.value || 'conventional';
    const fd = new FormData();
    fd.append('file', file);
    fd.append('model', algo);
    fd.append('clahe_clip_limit', String(p_clip.value));
    fd.append('clahe_tile_grid', String(p_grid.value));
    fd.append('adaptive_block_size', String(p_ablock.value));
    fd.append('adaptive_c', String(p_ac.value));
    fd.append('morph_kernel_xy', String(p_mkerxy.value));
    fd.append('morph_iters', String(p_mitr.value));
    fd.append('area_threshold', String(p_area.value));
    const cropChecked = p_crop.checked;
    fd.append('crop', String(cropChecked));
    if (cropChecked) fd.append('crop_percent', String(p_cpercent.value));
    return fd;
  }

  // File preview + metadata
  function updateFileName() {
    if (fileInput.files.length) {
      const file = fileInput.files[0];
      fileName.textContent = file.name;

      const reader = new FileReader();
      reader.onload = () => {
        thumb.src = reader.result;
        const img = new Image();
        img.onload = () => {
          const kb = (file.size / 1024);
          const pretty = kb > 1024 ? (kb/1024).toFixed(2) + ' MB' : kb.toFixed(0) + ' KB';
          metaLine.textContent = `Size: ${pretty} • Dimensions: ${img.width}×${img.height} px`;
          thumbWrap.hidden = false;
          recomputeReadyState();
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    } else {
      fileName.textContent = '';
      thumb.removeAttribute('src');
      metaLine.textContent = '';
      thumbWrap.hidden = true;
    }
    recomputeReadyState();
    updateSampleVisibility();
  }

  // Browse & change
  browseBtn?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', updateFileName);

  // Drag & drop
  ['dragenter', 'dragover'].forEach(evt => {
    dropZone?.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add('dragover');
    });
  });
  ['dragleave', 'drop'].forEach(evt => {
    dropZone?.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove('dragover');
    });
  });
  dropZone?.addEventListener('drop', (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      updateFileName();
    }
  });

  function toggleParams() {
    if (!convFields) return;
    convFields.style.display = (algoSelect.value === 'conventional') ? 'block' : 'none';
    recomputeReadyState();
  }
  algoSelect?.addEventListener('change', toggleParams);
  toggleParams();

  [p_clip, p_grid, p_ablock, p_ac, p_mkerxy, p_mitr, p_area, p_cpercent].forEach(el => {
    el?.addEventListener('input', recomputeReadyState);
  });

  // Copy report (from <pre>)
  copyBtn?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(reportBox.textContent || '');
      copyBtn.classList.remove('btn-outline-secondary');
      copyBtn.classList.add('btn-success');
      copyBtn.textContent = 'Copied';
      setTimeout(() => {
        copyBtn.classList.remove('btn-success');
        copyBtn.classList.add('btn-outline-secondary');
        copyBtn.textContent = 'Copy';
      }, 1200);
    } catch (_) {}
  });

  // Reset
  resetBtn && resetBtn.addEventListener('click', () => {
    clearStatus();
    showResults(false);
    showReport(false);
    fileName.textContent = '';
    if (fileInput) fileInput.value = '';
    updateSampleVisibility();
    thumb.removeAttribute('src');
    metaLine.textContent = '';
    thumbWrap.hidden = true;

    p_clip.value = '2.0';
    p_grid.value = '8,8';
    p_ablock.value = '13';
    p_ac.value = '40';
    p_mkerxy.value = '5,5';
    p_mitr.value = '0';
    p_area.value = '95';
    p_crop.checked = false;
    p_cpercent.value = '10';
    p_cpercent.disabled = true;

    algoSelect.value = 'conventional';
    reportBox.textContent = '';  // clear summary
    toggleParams();
    recomputeReadyState();
  });

  // Submit handler with single-request guard
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (inProgress) return;
    inProgress = true;

    if (inFlight) inFlight.abort();
    inFlight = new AbortController();

    clearStatus();
    showResults(false);
    showReport(false);

    try {
      const file = fileInput.files[0];
      validateFile(file);
      validateParams();

      const fd = buildFormData();

      showStatus('info', 'Processing… please wait');
      runBtn.disabled = true;

      const res = await fetch(API_SEGMENT, { method: 'POST', body: fd, signal: inFlight.signal });
      let payload;
      try { payload = await res.json(); }
      catch { throw new Error('Server returned a non-JSON response'); }

      if (!res.ok || payload.ok === false) {
        const detail = payload?.error?.detail || res.statusText || 'Unknown error';
        throw new Error(detail);
      }

      // Render images
      setImg(imgInput, payload.images?.input_png_b64);
      setImg(imgMask, payload.images?.mask_png_b64);
      setImg(imgOverlay, payload.images?.overlay_png_b64);
      setImg(imgOrientation, payload.images?.orientation_map_png_b64);
      setImg(imgSizeHist, payload.images?.size_histogram_png_b64);
      setImg(imgAngleHist, payload.images?.angle_histogram_png_b64);

      // Metrics
      let fracPctText = '—';
      let countTxtText = '—';
      if (payload.metrics) {
        const frac = Number(payload.metrics.mask_area_fraction);
        if (Number.isFinite(frac)) fracPctText = (frac * 100).toFixed(2) + '%';
        countTxtText = (payload.metrics.hydride_count ?? '—');
      }
      metricArea.textContent = fracPctText;
      metricCount.textContent = countTxtText;

      // Report (include elapsed time if provided)
      const imageName = file?.name || '';
      const modelName = payload.model || (algoSelect.value || 'conventional');
      const elapsed = (typeof payload.elapsed_ms === 'number') ? `${payload.elapsed_ms} ms` : '—';

      const summaryText =
`Input image name: ${imageName}
Algorithm used: ${modelName}
Hydride area fraction: ${fracPctText}
Hydride count: ${countTxtText}
Time taken: ${elapsed}`;

      reportBox.textContent = summaryText;
      showReport(true);
      showResults(true);
      showStatus('info', (payload.message || 'Success') +". Please scroll down to see results!! You can download them as zip file too!!");
    } catch (err) {
      if (err.name === 'AbortError') {
        showStatus('info', 'Request aborted');
      } else {
        showStatus('error', err.message || String(err));
      }
    } finally {
      inProgress = false;
      runBtn.disabled = false;
      inFlight = null;
      recomputeReadyState();
    }
  });

  // Download ZIP handler
  downloadZipBtn?.addEventListener('click', async () => {
    try {
      const file = fileInput.files[0];
      validateFile(file);
      validateParams();

      const fd = buildFormData();

      const res = await fetch(API_ZIP, { method: 'POST', body: fd });
      if (!res.ok) {
        let errTxt = 'Failed to download ZIP';
        try {
          const j = await res.json();
          errTxt = j?.error?.detail || errTxt;
        } catch (_) {}
        showStatus('error', errTxt);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'hydride_results.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      showStatus('error', err.message || String(err));
    }
  });

  // Initial state
  recomputeReadyState();
  updateSampleVisibility();
});
