"""ml_server package."""

from . import tasks  # noqa: F401  ensure tasks are registered
