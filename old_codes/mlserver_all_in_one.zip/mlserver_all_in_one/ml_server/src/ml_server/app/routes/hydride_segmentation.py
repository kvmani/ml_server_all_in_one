# src/ml_server/app/routes/hydride_segmentation.py
"""UI routes for Hydride Segmentation (renders the page only)."""

from __future__ import annotations

from flask import Blueprint, render_template

# IMPORTANT: use a NEW blueprint name to avoid conflicts with the API blueprint
hydride_ui = Blueprint("hydride_ui", __name__)

@hydride_ui.get("/hydride_segmentation", endpoint="hydride_segmentation_page")
def hydride_segmentation_page():
    """
    Render the Hydride Segmentation page.

    All processing is handled client-side via JS, which POSTs to the embedded API:
    /api/v1/hydride_segmentation/segment
    """
    return render_template("hydride_segmentation.html")
