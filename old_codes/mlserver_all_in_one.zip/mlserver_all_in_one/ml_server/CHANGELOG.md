# Changelog

## [Unreleased]
- Switch Docker services to run with Gunicorn directly via command line options.
- Added `gunicorn` and `Flask-Compress` dependencies for production deployment.
- New development and architecture documents in `docs/`.
- Introduced this changelog.
