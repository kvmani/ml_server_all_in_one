"""Core GUI and analysis modules."""
