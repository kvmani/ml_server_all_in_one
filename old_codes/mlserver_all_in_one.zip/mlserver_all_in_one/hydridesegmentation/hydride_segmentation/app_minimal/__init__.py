"""Minimal standalone Flask application for manual testing."""
from .app import create_app

__all__ = ["create_app"]
