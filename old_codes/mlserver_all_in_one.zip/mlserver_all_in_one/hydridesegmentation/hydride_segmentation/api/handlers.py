"""Request handlers for the segmentation API."""
from __future__ import annotations

import imghdr
import time
from typing import Dict

from hydride_segmentation.core.utils import load_image_from_bytes
from .schema import SegmentParams

ALLOWED_EXTS = {"png", "jpg", "jpeg", "tif", "tiff", "bmp"}
MAX_SIZE_MB = 20


def _validate_and_read_file(file_storage) -> bytes:
    if file_storage is None or file_storage.filename == "":
        raise ValueError("file is required")
    filename = file_storage.filename
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED_EXTS:
        raise ValueError("unsupported file type")
    data = file_storage.read()
    if len(data) > MAX_SIZE_MB * 1024 * 1024:
        raise ValueError("file too large")
    kind = imghdr.what(None, h=data)
    if kind not in ALLOWED_EXTS:
        raise ValueError("unsupported file type")
    return data


def process_request(file_storage, params: SegmentParams) -> Dict:
    """Process request and return response dictionary."""
    if params.model == "ml":
        return {
            "ok": True,
            "model": "ml",
            "message": "ML model will be available soon",
            "metrics": {},
            "images": {},
        }

    t0 = time.perf_counter()  # <-- START TIMER

    # ---- Decode → ndarray and make GRAY/RGB variants (GUI expects gray)
    data = _validate_and_read_file(file_storage)
    img_nd = load_image_from_bytes(data)  # np.ndarray (BGR or GRAY)

    import cv2
    if img_nd.ndim == 3 and img_nd.shape[2] == 3:
        img_gray = cv2.cvtColor(img_nd, cv2.COLOR_BGR2GRAY)
        img_rgb = cv2.cvtColor(img_nd, cv2.COLOR_BGR2RGB)
    else:
        img_gray = img_nd
        img_rgb = cv2.cvtColor(img_nd, cv2.COLOR_GRAY2RGB)

    # ---- Normalize incoming params to the nested GUI dict
    gui_params = params.to_gui_params()

    # ---- Import and run the pipeline (code you already have)
    import importlib.util
    from pathlib import Path

    segmod = None
    import_error_details = []
    try:
        segmod = importlib.import_module("hydride_segmentation.segmentationMaskCreation")
    except Exception as e:
        import_error_details.append(("hydride_segmentation.segmentationMaskCreation", repr(e)))
    if segmod is None:
        try:
            segmod = importlib.import_module("segmentationMaskCreation")
        except Exception as e:
            import_error_details.append(("segmentationMaskCreation", repr(e)))
    if segmod is None:
        try:
            import hydride_segmentation as hs_pkg
            pkg_dir = Path(hs_pkg.__file__).resolve().parent
            candidates = [pkg_dir / "segmentationMaskCreation.py", pkg_dir.parent / "segmentationMaskCreation.py"]
            for candidate in candidates:
                if candidate.exists():
                    spec = importlib.util.spec_from_file_location("segmentationMaskCreation", str(candidate))
                    mod = importlib.util.module_from_spec(spec)
                    assert spec.loader is not None
                    spec.loader.exec_module(mod)
                    segmod = mod
                    break
            if segmod is None:
                import_error_details.append(("file_lookup", f"not found at {', '.join(str(c) for c in candidates)}"))
        except Exception as e:
            import_error_details.append(("file_lookup", repr(e)))
    if segmod is None:
        detail_lines = "\n".join([f"- tried {where}: {msg}" for where, msg in import_error_details])
        raise RuntimeError("Could not import segmentationMaskCreation.\n" + detail_lines)
    if not hasattr(segmod, "run_model_ndarray"):
        raise RuntimeError("segmentationMaskCreation.run_model_ndarray is missing")

    image_gray_used, mask = segmod.run_model_ndarray(img_gray, gui_params)

    overlay = img_rgb.copy()
    overlay[mask > 0] = [255, 0, 0]

    from hydride_segmentation.core.analysis import compute_metrics, analyze_mask
    metrics = compute_metrics(mask)
    analysis_imgs = analyze_mask(mask)

    elapsed_ms = int((time.perf_counter() - t0) * 1000)  # <-- END TIMER

    from hydride_segmentation.core.utils import image_to_png_base64
    return {
        "ok": True,
        "model": "conventional",
        "metrics": metrics,
        "elapsed_ms": elapsed_ms,  # <-- NEW
        "images": {
            "input_png_b64": image_to_png_base64(img_rgb),
            "mask_png_b64": image_to_png_base64(mask),
            "overlay_png_b64": image_to_png_base64(overlay),
            "orientation_map_png_b64": analysis_imgs["orientation_map_png_b64"],
            "size_histogram_png_b64": analysis_imgs["size_histogram_png_b64"],
            "angle_histogram_png_b64": analysis_imgs["angle_histogram_png_b64"],
        },
        "message": "success",
    }
