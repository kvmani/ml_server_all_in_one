from __future__ import annotations

import base64
import datetime
import io
import zipfile

from flask import Blueprint, jsonify, request, Response

from .handlers import process_request
from .schema import SegmentParams


def create_blueprint() -> Blueprint:
    """
    Factory used by ml_server:
        from hydride_segmentation.api import create_blueprint
        app.register_blueprint(create_blueprint(), url_prefix="/api/v1/hydride_segmentation")
    """
    bp = Blueprint("hydride_segmentation", __name__)

    @bp.route("/segment", methods=["POST"])
    def segment_endpoint():
        try:
            params = SegmentParams(**request.form.to_dict(flat=True))
            resp = process_request(request.files.get("file"), params)
            status = 200 if resp.get("ok") else 400
            return jsonify(resp), status
        except Exception as e:  # noqa: BLE001
            return jsonify({"ok": False, "error": {"detail": str(e)}}), 500

    @bp.route("/zip", methods=["POST"])
    def zip_endpoint():
        """
        Re-computes results (same as /segment) and returns a ZIP:
          - input.png, mask.png, overlay.png
          - orientation_map.png, size_hist.png, angle_hist.png
          - results.txt (summary + echoed params)
        """
        try:
            params = SegmentParams(**request.form.to_dict(flat=True))
            resp = process_request(request.files.get("file"), params)
            if not resp.get("ok", False):
                return jsonify(resp), 400

            images = resp["images"]
            metrics = resp.get("metrics", {})
            elapsed_ms = resp.get("elapsed_ms", None)
            model = resp.get("model", "conventional")
            filename = request.files.get("file").filename if request.files.get("file") else "input.png"

            # Build results.txt
            def pct(frac):
                try:
                    return f"{float(frac) * 100:.2f}%"
                except Exception:
                    return "—"

            lines = [
                f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
                f"Input image name: {filename}",
                f"Algorithm used: {model}",
                f"Hydride area fraction: {pct(metrics.get('mask_area_fraction'))}",
                f"Hydride count: {metrics.get('hydride_count', '—')}",
            ]
            if elapsed_ms is not None:
                lines.append(f"Time taken: {elapsed_ms} ms")
            # Echo key params if present
            for key in [
                "clahe_clip_limit", "clahe_tile_grid",
                "adaptive_block_size", "adaptive_c",
                "morph_kernel_xy", "morph_iters",
                "area_threshold", "crop", "crop_percent",
            ]:
                if key in request.form:
                    lines.append(f"{key}: {request.form[key]}")
            results_txt = "\n".join(lines).encode("utf-8")

            # Helper to add base64 PNGs to zip
            def add_png(zf, arcname, b64):
                if not b64:
                    return
                zf.writestr(arcname, base64.b64decode(b64))

            mem = io.BytesIO()
            with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
                add_png(zf, "input.png", images.get("input_png_b64"))
                add_png(zf, "mask.png", images.get("mask_png_b64"))
                add_png(zf, "overlay.png", images.get("overlay_png_b64"))
                add_png(zf, "orientation_map.png", images.get("orientation_map_png_b64"))
                add_png(zf, "size_hist.png", images.get("size_histogram_png_b64"))
                add_png(zf, "angle_hist.png", images.get("angle_histogram_png_b64"))
                zf.writestr("results.txt", results_txt)

            mem.seek(0)
            return Response(
                mem.getvalue(),
                mimetype="application/zip",
                headers={
                    "Content-Disposition": "attachment; filename=hydride_results.zip",
                    "Cache-Control": "no-store",
                },
            )
        except Exception as e:  # noqa: BLE001
            return jsonify({"ok": False, "error": {"detail": str(e)}}), 500

    return bp
