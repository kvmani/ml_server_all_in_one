from __future__ import annotations

from typing import Optional, Tuple, Dict, Any

from pydantic import BaseModel, Field, validator


def _parse_pair(s: str, label: str, min_v: int = 1) -> Tuple[int, int]:
    try:
        x_s, y_s = [t.strip() for t in s.split(",")]
        x, y = int(x_s), int(y_s)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"{label} must be 'X,Y' integers") from e
    if x < min_v or y < min_v:
        raise ValueError(f"{label} must be ≥ {min_v}")
    return x, y


class SegmentParams(BaseModel):
    # Common
    model: str = Field(default="conventional")

    # CLAHE
    clahe_clip_limit: float = Field(default=2.0, gt=0)
    clahe_tile_grid: str = Field(default="8,8")  # "X,Y" (GUI style)

    # Legacy web names (kept for compatibility)
    adaptive_window: Optional[int] = None  # odd ≥ 3
    adaptive_offset: Optional[int] = None
    morph_kernel: Optional[int] = None  # single int (square)

    # GUI-aligned names (Tkinter)
    adaptive_block_size: Optional[int] = None  # odd ≥ 3
    adaptive_c: Optional[int] = None
    morph_kernel_xy: Optional[str] = None  # "X,Y"

    # Shared
    morph_iters: int = Field(default=0, ge=0)
    area_threshold: int = Field(default=95, ge=0)

    # Optional crop
    crop: bool = False
    crop_percent: int = Field(default=0, ge=0, le=90)

    @validator("clahe_tile_grid")
    def _grid_str(cls, v: str) -> str:
        if "," not in v:
            raise ValueError("clahe_tile_grid must be 'X,Y'")
        return v

    def to_gui_params(self) -> Dict[str, Any]:
        """Normalize to the exact nested dict that GUI uses in run_model()."""
        tile_x, tile_y = _parse_pair(self.clahe_tile_grid, "CLAHE tile grid", 1)

        # block size (prefer GUI name)
        bs = self.adaptive_block_size or self.adaptive_window or 13
        bs = int(bs)
        if bs < 3 or (bs % 2) == 0:
            raise ValueError("adaptive block size must be odd ≥ 3")

        # C (prefer GUI name)
        c = int(self.adaptive_c if self.adaptive_c is not None else (self.adaptive_offset or 0))

        # kernel (prefer GUI "X,Y"; else legacy square)
        if self.morph_kernel_xy:
            kx, ky = _parse_pair(self.morph_kernel_xy, "morph kernel size", 1)
        else:
            k = int(self.morph_kernel or 3)
            if k < 1:
                raise ValueError("morph_kernel must be ≥ 1")
            kx, ky = k, k

        crop = bool(self.crop)
        crop_percent = int(self.crop_percent or 0)
        if not crop:
            crop_percent = 0

        return {
            'clahe': {'clip_limit': float(self.clahe_clip_limit), 'tile_grid_size': [int(tile_x), int(tile_y)]},
            'adaptive': {'block_size': int(bs), 'C': int(c)},
            'morph': {'kernel_size': [int(kx), int(ky)], 'iterations': int(self.morph_iters)},
            'area_threshold': int(self.area_threshold),
            'crop': crop,
            'crop_percent': crop_percent
        }
